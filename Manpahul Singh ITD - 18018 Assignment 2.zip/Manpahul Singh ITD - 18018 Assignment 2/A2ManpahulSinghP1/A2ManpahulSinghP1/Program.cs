﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A2ManpahulSinghP1
{
    class Program
    {

        static double taxamount(int amount, int tax)
        {
            double finalamount = amount * tax / 100;
            return finalamount;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Are you a canadian citizen? Press y for yes and n for no.");
            string cadon = Console.ReadLine();
            Console.WriteLine("What is your age?");
            string ages = Console.ReadLine();
            int age = int.Parse(ages);

            int basecharge, internationalcharges;
            int tax = 13;
            string intstud;

            if (cadon == "y")
            {
                intstud = "NO";
                internationalcharges = 100;
            }

            else
            {
                intstud = "YES";
                internationalcharges = 0;
            }
            
            if (age <= 18)
            {
                basecharge = 300;

            }

            else if (age <= 49)
            {
                basecharge = 500;
            }

            else
            {
                basecharge = 400;
            }

            int semifinalamount1 = basecharge + internationalcharges;

            Console.WriteLine("Whichh month were you registered? Enter the number of the month and press enter");
            string monthnumber = Console.ReadLine();
            int month = int.Parse(monthnumber);

            int regamt;

            switch (month)
            {
               
                case 1:
                    {
                        regamt = 220;
                        break;
                    }

                case 2:
                    {
                        regamt = 220;
                        break;
                    }

                case 3:
                    {
                        regamt = 220;
                        break;
                    }

                case 4:
                    {
                        regamt = 220;
                        break;
                    }

                case 5:
                    {
                        regamt = 150;
                        break;
                    }

                case 6:
                    {
                        regamt = 150;
                        break;
                    }

                case 7:
                    {
                        regamt = 150;
                        break;
                    }

                case 8:
                    {
                        regamt = 150;
                        break;
                    }

                case 9:
                    {
                        regamt = 250;
                        break;
                    }

                case 10:
                    {
                        regamt = 250;
                        break;
                    }

                case 11:
                    {
                        regamt = 250;
                        break;
                    }

                case 12:
                    {
                        regamt = 250;
                        break;
                    }

                default:
                    {
                        regamt = 0;
                        break;
                    }

            }

            int finalamount = semifinalamount1 + regamt;

            double taxamt = taxamount(finalamount, tax);

            double totalfinal = taxamt + finalamount;

            Console.WriteLine("Student's age " + age);
            Console.WriteLine("International student or not: " + intstud);
            Console.WriteLine("Base tution (in dollars): " + basecharge);
            Console.WriteLine("International student fee (in dollars): " + internationalcharges);
            Console.WriteLine("Registeration fee for the semester (in dollars): " + regamt);
            Console.WriteLine("HST (in dollars): " + taxamt);
            Console.WriteLine("Final total (in dollars): " + totalfinal);

        }
    }
}