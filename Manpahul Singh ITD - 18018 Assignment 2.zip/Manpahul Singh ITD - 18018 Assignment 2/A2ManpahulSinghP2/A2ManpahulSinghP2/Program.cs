﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A2ManpahulSinghP2
{
    class Program
    {

        static void volume()
        {
            double pi = 3.14159;
            Console.WriteLine("Please enter the radius");
            string radsph = Console.ReadLine();
            double rs = double.Parse(radsph);
            double vs = 4 / 3 * pi * rs * rs * rs;
            Console.WriteLine("The volume of sphere is " + vs);
        }

        static double volume(double r, double h)
        {
            double pi = 3.14159;
            double vol = pi * r * r * h;
            return vol;
        }

        static float volume(float l, float b, float h)
        {
            float vol = l * b * h;
            return vol;
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Please type in the number that corresponds to the shape you are willing to calculate the volume of and press enter");
            Console.WriteLine("1: Sphere");
            Console.WriteLine("2: Cylinder");
            Console.WriteLine("3: Rectangular prism");
            string menuoption = Console.ReadLine();
            
            if(menuoption == "1")
            {
                volume();

            }

            else if (menuoption == "2")
            {
                Console.WriteLine("Please enter the radius");
                string radcyl = Console.ReadLine();
                double rc = double.Parse(radcyl);
                Console.WriteLine("Please enter the height");
                string heicyl = Console.ReadLine();
                double hc = double.Parse(heicyl);
                double vc = volume(rc, hc);
                Console.WriteLine("The volume of cylinder is " + vc);
            }

            else if (menuoption == "3")
            {
                Console.WriteLine("Please enter the length");
                string lenpri = Console.ReadLine();
                float lp = float.Parse(lenpri);
                Console.WriteLine("Please enter the breadth");
                string brepri = Console.ReadLine();
                float bp = float.Parse(brepri);
                Console.WriteLine("Please enter the height");
                string heipri = Console.ReadLine();
                float hp = float.Parse(heipri);
                float vp = volume(lp, bp, hp);
                Console.WriteLine("The volume of Prism is " + vp);
            }
            else
            {
                Console.WriteLine("Please select a valid shape");

            }
        }
    }
}
